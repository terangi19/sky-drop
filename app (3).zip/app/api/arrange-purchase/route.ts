import { NextRequest, NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { verifyIdToken } from "../../lib/firebase-admin";
import { rateLimit } from "../../lib/rate-limit";
import { adminGetListing, requireAdminForCheckout } from "../../lib/checkout-server";
import {
  buildArrangePurchaseData,
  makePurchaseId,
} from "../../lib/purchase-service";
import {
  adminGetProfileByEmail,
  adminGetPublicHandle,
  adminGetPublicName,
} from "../../lib/profile-display-admin";
import {
  assertListingAvailableForPurchase,
  buildListingUpdateAfterSale,
  isListingAvailableForPurchase,
} from "../../lib/listing-stock";

function makeConversationId(listingId: string, buyerEmail: string): string {
  return `conv_${listingId}_${buyerEmail.replace(/[@.]/g, "_")}`;
}

export async function POST(req: NextRequest) {
  try {
    requireAdminForCheckout();

    const ip = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "unknown";
    const { allowed } = await rateLimit(`arrange-purchase:${ip}`, 15, 60_000);
    if (!allowed) {
      return NextResponse.json({ error: "Too many requests" }, { status: 429 });
    }

    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let decoded;
    try {
      decoded = await verifyIdToken(authHeader.slice(7));
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : "Invalid or expired token";
      return NextResponse.json({ error: message }, { status: 401 });
    }

    const buyerEmail = decoded.email || "";
    if (!buyerEmail) {
      return NextResponse.json({ error: "Could not determine buyer email" }, { status: 400 });
    }

    const { listingId, collectionName: colBody } = await req.json();
    const collectionName =
      typeof colBody === "string" && colBody ? colBody : "listings";
    if (!listingId) {
      return NextResponse.json({ error: "Missing listingId" }, { status: 400 });
    }

    const listing = await adminGetListing(collectionName, listingId);
    if (!listing) {
      return NextResponse.json({ error: "Listing not found" }, { status: 404 });
    }

    const paymentType = String(listing.paymentType || "stripe");
    if (paymentType !== "contact") {
      return NextResponse.json(
        {
          error:
            "This listing uses Stripe checkout. Use Buy Now instead of Arrange Purchase.",
        },
        { status: 400 }
      );
    }

    const sellerEmail = String(listing.sellerEmail || "");
    if (!sellerEmail) {
      return NextResponse.json({ error: "Listing has no seller" }, { status: 400 });
    }
    if (sellerEmail === buyerEmail) {
      return NextResponse.json({ error: "You cannot purchase your own listing" }, { status: 400 });
    }
    if (!isListingAvailableForPurchase(listing as Record<string, unknown>)) {
      return NextResponse.json(
        { error: "This listing is no longer available" },
        { status: 400 }
      );
    }

    const { getAdminDb } = await import("../../lib/firebase-admin");
    const db = getAdminDb();
    const buyerProfile = await adminGetProfileByEmail(buyerEmail);
    const buyerHandle = await adminGetPublicHandle(buyerEmail);
    const buyerName = await adminGetPublicName(buyerEmail);
    const listingRef = db.collection(collectionName).doc(listingId);
    const convId = makeConversationId(listingId, buyerEmail);
    const convRef = db.collection("conversations").doc(convId);
    const title = String(listing.title || "Item");
    const price = String(listing.price || "0");
    const image =
      (Array.isArray(listing.images) ? listing.images[0] : "") ||
      String(listing.imageUrl || listing.image || "");

    const purchaseId = makePurchaseId(listingId, buyerEmail);
    const purchaseRef = db.collection("purchases").doc(purchaseId);
    let conversationId = convId;
    let isExisting = false;

    await db.runTransaction(async (tx) => {
      const listingSnap = await tx.get(listingRef);
      const convSnap = await tx.get(convRef);
      const purchaseSnap = await tx.get(purchaseRef);

      if (!listingSnap.exists) throw new Error("Listing not found");
      const data = listingSnap.data()!;

      if (purchaseSnap.exists) {
        isExisting = true;
        conversationId = String(purchaseSnap.data()?.conversationId || convId);
        return;
      }

      assertListingAvailableForPurchase(data);

      const listingUpdate = buildListingUpdateAfterSale(data, {
        soldTo: buyerEmail,
        useServerTimestamp: true,
      });
      if (Object.keys(listingUpdate).length > 0) {
        tx.update(listingRef, listingUpdate);
      }

      if (convSnap.exists) {
        tx.update(convRef, {
          updatedAt: FieldValue.serverTimestamp(),
          lastMessage: "Item purchased — arrange payment in chat",
          orderStatus: "arranged",
        });
      } else {
        tx.set(convRef, {
          convKey: `listing_${listingId}`,
          participants: [buyerEmail, sellerEmail],
          buyerEmail,
          sellerEmail,
          listingId,
          listingTitle: title,
          listingPrice: price,
          listingImage: image,
          orderStatus: "arranged",
          paymentType: "contact",
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
          lastMessage: "Item purchased — arrange payment in chat",
        });
      }

      const buyerMsg = db.collection("messages").doc();
      tx.set(buyerMsg, {
        type: "system",
        text: `🤝 Item purchased: "${title}" for $${price}\n\nYou're now connected with the seller. Use this chat to arrange payment and delivery details.\n\nPlease keep all communication inside Sky Drop for protection.`,
        sender: "system",
        receiver: sellerEmail,
        participants: [buyerEmail],
        conversationId: convId,
        listingId,
        listingTitle: title,
        read: false,
        createdAt: FieldValue.serverTimestamp(),
      });

      const sellerMsg = db.collection("messages").doc();
      tx.set(sellerMsg, {
        type: "text",
        text: `🟢 This item has been purchased by ${buyerHandle}.\n\nUse this chat to arrange:\n• payment method (bank transfer, cash, etc.)\n• shipping or pickup\n• timing\n\nKeep all communication inside Sky Drop for protection.`,
        sender: "system",
        receiver: sellerEmail,
        participants: [sellerEmail],
        conversationId: convId,
        listingId,
        listingTitle: title,
        read: false,
        createdAt: FieldValue.serverTimestamp(),
      });

      tx.set(
        purchaseRef,
        buildArrangePurchaseData(
          listing as Record<string, unknown>,
          listingId,
          buyerEmail,
          convId,
          collectionName,
          buyerName
        )
      );
    });

    return NextResponse.json({
      success: true,
      conversationId,
      sellerEmail,
      purchaseId,
      existing: isExisting,
    });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "Failed to arrange purchase";
    console.error("[arrange-purchase]", msg);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
