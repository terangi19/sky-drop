import { auth } from "./firebase";

const NZ_PREFIXES = ["021", "022", "027", "028", "029"];

function isDev(): boolean {
  return typeof window !== "undefined" && window.location.hostname === "localhost";
}

export function formatNZPhone(input: string): string {
  const digits = input.replace(/\D/g, "");
  if (digits.startsWith("642") && digits.length >= 10) return `+${digits}`;
  if (digits.startsWith("64") && digits.length >= 10) return `+${digits}`;
  for (const prefix of NZ_PREFIXES) {
    if (digits.startsWith(prefix.slice(1)) && digits.length >= 10) return `+642${digits.slice(2)}`;
    if (digits.startsWith(prefix) && digits.length >= 8) return `+64${digits.slice(1)}`;
  }
  if (digits.startsWith("0") && digits.length >= 8) return `+64${digits.slice(1)}`;
  if (!digits.startsWith("+")) return `+${digits}`;
  return digits;
}

export function maskPhone(phone: string): string {
  const d = phone.replace(/\D/g, "");
  if (d.length <= 4) return phone;
  return `***${d.slice(-4)}`;
}

function errorMessage(e: any): string {
  const msg = e?.message || e?.code || "";
  if (msg.includes("operation-not-allowed") || msg.includes("OPERATION_NOT_ALLOWED"))
    return "Phone authentication is not enabled. Ask the site owner to enable it in Firebase Console.";
  if (msg.includes("invalid-phone-number") || msg.includes("INVALID_PHONE_NUMBER"))
    return "Invalid phone number. Use a valid NZ number like 021 123 4567.";
  if (msg.includes("TOO_MANY_ATTEMPTS") || msg.includes("too-many-requests"))
    return "Too many attempts. Wait a moment and try again.";
  if (msg.includes("invalid-app-credential") || msg.includes("INVALID_APP_CREDENTIAL"))
    return "SMS verification is unavailable in this environment. Try on a phone or deploy to production.";
  if (msg.includes("SESSION_EXPIRED") || msg.includes("expired"))
    return "Code expired. Request a new one.";
  if (msg.includes("INVALID_CODE") || msg.includes("invalid-verification-code"))
    return "Invalid code. Check the code sent to your phone and try again.";
  if (msg.includes("captcha-check-failed") || msg.includes("recaptcha"))
    return "Security check failed. Please try again.";
  return msg || "Failed to send code.";
}

export async function sendPhoneCode(phone: string): Promise<{
  sent: boolean;
  error?: string;
  formattedPhone?: string;
}> {
  const formatted = formatNZPhone(phone);

  // Dev mode — skip SMS, use code 000000
  if (isDev()) {
    (window as any).__devPhoneCode = "000000";
    (window as any).__devFormattedPhone = formatted;
    return { sent: true, formattedPhone: formatted };
  }

  try {
    const { RecaptchaVerifier, signInWithPhoneNumber } = await import("firebase/auth");

    if ((window as any).__recaptchaVerifier) {
      try { (window as any).__recaptchaVerifier.clear(); } catch {}
    }
    (window as any).__recaptchaVerifier = null;

    const container = document.getElementById("recaptcha-container");
    if (container) container.innerHTML = "";

    const verifier = new RecaptchaVerifier(auth, "recaptcha-container", { size: "invisible" });
    (window as any).__recaptchaVerifier = verifier;

    const confirmation = await signInWithPhoneNumber(auth, formatted, verifier);
    (window as any).__phoneConfirmation = confirmation;

    return { sent: true, formattedPhone: formatted };
  } catch (e: any) {
    return { sent: false, error: errorMessage(e) };
  }
}

export async function verifyPhoneCode(inputCode: string): Promise<{ ok: boolean; error?: string }> {
  // Dev mode — accept 000000
  if (isDev()) {
    if ((window as any).__devPhoneCode && inputCode.trim() === (window as any).__devPhoneCode) {
      (window as any).__devPhoneCode = null;
      (window as any).__devFormattedPhone = null;
      return { ok: true };
    }
    return { ok: false, error: "Invalid code. Use 000000 in development." };
  }

  const confirmation = (window as any).__phoneConfirmation;
  if (!confirmation) {
    return { ok: false, error: "No code sent. Click Send Code first." };
  }

  try {
    await confirmation.confirm(inputCode);
    (window as any).__phoneConfirmation = null;
    if ((window as any).__recaptchaVerifier) {
      try { (window as any).__recaptchaVerifier.clear(); } catch {}
    }
    (window as any).__recaptchaVerifier = null;
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: errorMessage(e) };
  }
}
