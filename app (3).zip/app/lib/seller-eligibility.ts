/** Why a user cannot create a paid listing (null = OK). */
export function getListingBlockReason(opts: {
  authEmailVerified: boolean;
  phone?: string;
  phoneVerified?: boolean;
  restricted?: boolean;
  profileExists?: boolean;
}): string | null {
  if (opts.restricted) {
    return "Your account is temporarily restricted.";
  }
  if (opts.profileExists === false) {
    return "Please complete your profile first.";
  }
  if (!opts.authEmailVerified) {
    return "Verify your email — check your inbox (and spam), then use “Refresh status” on Profile.";
  }
  const phone = String(opts.phone || "").trim();
  if (!phone || !opts.phoneVerified) {
    return "Add and verify your phone number on Profile to create listings.";
  }
  return null;
}

export function canCreateListing(opts: Parameters<typeof getListingBlockReason>[0]): boolean {
  return getListingBlockReason(opts) === null;
}
